<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function activity_response(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

if (empty($_SESSION['user_id'])) activity_response(401, ['ok'=>false, 'message'=>'Please sign in first.']);
$admin = $pdo->prepare("SELECT id, role FROM users WHERE id = ? LIMIT 1");
$admin->execute([(int)$_SESSION['user_id']]);
$actor = $admin->fetch(PDO::FETCH_ASSOC);
if (!$actor || $actor['role'] !== 'admin') activity_response(403, ['ok'=>false, 'message'=>'Administrator access is required.']);

try {
    // Create the audit table automatically; existing project tables and records are untouched.
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_activity_log (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NULL,
        action VARCHAR(120) NOT NULL,
        details TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_activity_created_at (created_at),
        INDEX idx_activity_user_id (user_id),
        CONSTRAINT fk_admin_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $limit = 250;
        // Hide historical prototype/demo entries from the real audit view.
        // Keep the underlying rows intact; this is a non-destructive display filter.
        $stmt = $pdo->prepare("SELECT l.id, l.action, l.details, l.created_at, COALESCE(u.email, 'Deleted administrator') AS actor_email
            FROM admin_activity_log l LEFT JOIN users u ON u.id = l.user_id
            WHERE l.action NOT IN ('Sample demo data loaded', 'Admin dashboard opened')
              AND NOT (l.action = 'Utility account added' AND l.details IN (
                  'AEDC (Abuja) · 00000000001',
                  'IKEDC (Ikeja) · 00000000002'
              ))
            ORDER BY l.created_at DESC, l.id DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        activity_response(200, ['ok'=>true, 'activities'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') activity_response(405, ['ok'=>false, 'message'=>'Method not allowed.']);
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) activity_response(400, ['ok'=>false, 'message'=>'Invalid activity data.']);
    $action = trim((string)($input['action'] ?? ''));
    $details = trim((string)($input['details'] ?? ''));
    if ($action === '' || mb_strlen($action) > 120 || mb_strlen($details) > 4000) {
        activity_response(422, ['ok'=>false, 'message'=>'Activity name or details are invalid.']);
    }
    // Ignore dashboard-open events even if an older browser script still sends them.
    if ($action === 'Admin dashboard opened') {
        activity_response(200, ['ok'=>true, 'ignored'=>true, 'message'=>'Dashboard navigation is not recorded.']);
    }
    $insert = $pdo->prepare('INSERT INTO admin_activity_log (user_id, action, details) VALUES (?, ?, ?)');
    $insert->execute([(int)$actor['id'], $action, $details !== '' ? $details : null]);
    activity_response(201, ['ok'=>true, 'id'=>(int)$pdo->lastInsertId(), 'message'=>'Activity saved.']);
} catch (Throwable $e) {
    error_log('Meterly admin activity log error: ' . $e->getMessage());
    activity_response(500, ['ok'=>false, 'message'=>'Could not access the permanent activity log. Check the PHP error log.']);
}
