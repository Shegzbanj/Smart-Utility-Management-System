<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function bill_api_response(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}
function bill_text(mixed $value): string {
    if (!is_string($value) && !is_numeric($value)) return '';
    return trim((string)$value);
}
function ensure_bill_audit_table(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_activity_log (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NULL,
        action VARCHAR(120) NOT NULL,
        details TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_activity_created_at (created_at),
        INDEX idx_activity_user_id (user_id),
        CONSTRAINT fk_admin_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}
function write_bill_audit(PDO $pdo, int $userId, string $action, string $details): void {
    $stmt = $pdo->prepare('INSERT INTO admin_activity_log (user_id, action, details) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $action, $details]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') bill_api_response(405, ['ok'=>false, 'message'=>'Method not allowed.']);
if (empty($_SESSION['user_id'])) bill_api_response(401, ['ok'=>false, 'message'=>'Please sign in first.']);
$adminId = (int)$_SESSION['user_id'];
$check = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
$check->execute([$adminId]);
if ($check->fetchColumn() !== 'admin') bill_api_response(403, ['ok'=>false, 'message'=>'Administrator access is required.']);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) bill_api_response(400, ['ok'=>false, 'message'=>'Invalid request data.']);
$action = (string)($input['action'] ?? '');

try {
    // Create the audit table before beginning the data transaction (CREATE TABLE can implicitly commit).
    ensure_bill_audit_table($pdo);
    $pdo->beginTransaction();

    if ($action === 'delete') {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id || $id < 1) { $pdo->rollBack(); bill_api_response(422, ['ok'=>false, 'message'=>'A valid bill ID is required.']); }
        $find = $pdo->prepare('SELECT b.bill_title, b.amount, b.status, ua.account_number, ua.provider_name FROM bills b LEFT JOIN utility_accounts ua ON ua.id=b.utility_account_id WHERE b.id=? FOR UPDATE');
        $find->execute([$id]);
        $bill = $find->fetch(PDO::FETCH_ASSOC);
        if (!$bill) { $pdo->rollBack(); bill_api_response(404, ['ok'=>false, 'message'=>'Bill not found.']); }
        $stmt = $pdo->prepare('DELETE FROM bills WHERE id = ?');
        $stmt->execute([$id]);
        write_bill_audit($pdo, $adminId, 'Bill deleted', sprintf('Bill #%d · %s · ₦%s · %s', $id, $bill['bill_title'], number_format((float)$bill['amount'], 2), $bill['status']));
        $pdo->commit();
        bill_api_response(200, ['ok'=>true, 'message'=>'Bill deleted and activity recorded.']);
    }

    if (!in_array($action, ['create', 'update'], true)) { $pdo->rollBack(); bill_api_response(400, ['ok'=>false, 'message'=>'Unknown action.']); }
    $accountId = filter_var($input['utility_account_id'] ?? null, FILTER_VALIDATE_INT);
    $title = bill_text($input['bill_title'] ?? '');
    $amountRaw = $input['amount'] ?? null;
    $period = bill_text($input['billing_period'] ?? '');
    $dueDate = bill_text($input['due_date'] ?? '');
    $status = bill_text($input['status'] ?? '');
    $dateCheck = DateTime::createFromFormat('!Y-m-d', $dueDate);
    $amountValid = is_numeric($amountRaw) && is_finite((float)$amountRaw)
        && (float)$amountRaw > 0 && (float)$amountRaw <= 999999999.99
        && preg_match('/^\d{1,9}(\.\d{1,2})?$/', (string)$amountRaw);
    if (!$accountId || $accountId < 1 || $title === '' || mb_strlen($title) > 150 ||
        !$amountValid || $period === '' || mb_strlen($period) > 100 ||
        !$dateCheck || $dateCheck->format('Y-m-d') !== $dueDate ||
        !in_array($status, ['unpaid','paid','overdue'], true)) {
        $pdo->rollBack(); bill_api_response(422, ['ok'=>false, 'message'=>'Complete all fields with a valid account, positive amount, status, and due date.']);
    }
    $accountCheck = $pdo->prepare('SELECT id, provider_name, account_number FROM utility_accounts WHERE id = ?');
    $accountCheck->execute([$accountId]);
    $account = $accountCheck->fetch(PDO::FETCH_ASSOC);
    if (!$account) { $pdo->rollBack(); bill_api_response(422, ['ok'=>false, 'message'=>'The selected utility account was not found.']); }

    if ($action === 'create') {
        $stmt = $pdo->prepare('INSERT INTO bills (utility_account_id, bill_title, amount, billing_period, due_date, status) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$accountId, $title, (float)$amountRaw, $period, $dueDate, $status]);
        $id = (int)$pdo->lastInsertId();
        $auditAction = 'Bill created';
    } else {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id || $id < 1) { $pdo->rollBack(); bill_api_response(422, ['ok'=>false, 'message'=>'A valid bill ID is required.']); }
        $oldStmt = $pdo->prepare('SELECT bill_title, amount, status FROM bills WHERE id=? FOR UPDATE');
        $oldStmt->execute([$id]);
        $old = $oldStmt->fetch(PDO::FETCH_ASSOC);
        if (!$old) { $pdo->rollBack(); bill_api_response(404, ['ok'=>false, 'message'=>'Bill not found.']); }
        $stmt = $pdo->prepare('UPDATE bills SET utility_account_id=?, bill_title=?, amount=?, billing_period=?, due_date=?, status=? WHERE id=?');
        $stmt->execute([$accountId, $title, (float)$amountRaw, $period, $dueDate, $status, $id]);
        $auditAction = 'Bill updated';
    }
    $details = sprintf('Bill #%d · %s · ₦%s · %s · %s (%s)', $id, $title, number_format((float)$amountRaw, 2), $status, $account['provider_name'], $account['account_number']);
    if ($action === 'update') $details .= sprintf(' · Previous: %s · ₦%s · %s', $old['bill_title'], number_format((float)$old['amount'], 2), $old['status']);
    write_bill_audit($pdo, $adminId, $auditAction, $details);
    $pdo->commit();
    bill_api_response($action === 'create' ? 201 : 200, ['ok'=>true, 'message'=>($action === 'create' ? 'Bill created' : 'Bill updated').' successfully; activity recorded.']);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Meterly bill management error: ' . $e->getMessage());
    bill_api_response(500, ['ok'=>false, 'message'=>'Could not save this bill. Check the PHP error log and any linked payment/reminder records.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Meterly bill management error: ' . $e->getMessage());
    bill_api_response(500, ['ok'=>false, 'message'=>'An unexpected error occurred while managing this bill.']);
}
