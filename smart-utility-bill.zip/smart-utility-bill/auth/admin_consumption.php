<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function consumption_response(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') consumption_response(405, ['ok'=>false, 'message'=>'Method not allowed.']);
if (empty($_SESSION['user_id'])) consumption_response(401, ['ok'=>false, 'message'=>'Please sign in first.']);
$auth = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
$auth->execute([(int)$_SESSION['user_id']]);
if ($auth->fetchColumn() !== 'admin') consumption_response(403, ['ok'=>false, 'message'=>'Administrator access is required.']);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) consumption_response(400, ['ok'=>false, 'message'=>'Invalid request data.']);
$action = $input['action'] ?? '';
try {
    if ($action === 'delete') {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id || $id < 1) consumption_response(422, ['ok'=>false, 'message'=>'A valid record ID is required.']);
        $stmt = $pdo->prepare('DELETE FROM consumption_records WHERE id = ?');
        $stmt->execute([$id]);
        if (!$stmt->rowCount()) consumption_response(404, ['ok'=>false, 'message'=>'Consumption record not found.']);
        consumption_response(200, ['ok'=>true, 'message'=>'Consumption record deleted.']);
    }
    if (!in_array($action, ['create', 'update'], true)) consumption_response(400, ['ok'=>false, 'message'=>'Unknown action.']);
    $accountId = filter_var($input['utility_account_id'] ?? null, FILTER_VALIDATE_INT);
    $value = $input['consumption_value'] ?? null;
    $unitRaw = $input['unit'] ?? '';
    $dateRaw = $input['recorded_date'] ?? '';
    $unit = is_string($unitRaw) ? trim($unitRaw) : '';
    $date = is_string($dateRaw) ? trim($dateRaw) : '';
    $parsedDate = DateTime::createFromFormat('!Y-m-d', $date);
    $valueValid = is_numeric($value) && is_finite((float)$value)
        && (float)$value > 0 && (float)$value <= 999999999.99;
    if (!$accountId || $accountId < 1 || !$valueValid ||
        $unit === '' || mb_strlen($unit) > 30 || !$parsedDate || $parsedDate->format('Y-m-d') !== $date) {
        consumption_response(422, ['ok'=>false, 'message'=>'Choose an account and enter a positive consumption value, unit, and valid recorded date.']);
    }
    $account = $pdo->prepare('SELECT id FROM utility_accounts WHERE id = ?');
    $account->execute([$accountId]);
    if (!$account->fetchColumn()) consumption_response(422, ['ok'=>false, 'message'=>'The selected utility account was not found.']);
    if ($action === 'create') {
        $stmt = $pdo->prepare('INSERT INTO consumption_records (utility_account_id, consumption_value, unit, recorded_date) VALUES (?, ?, ?, ?)');
        $stmt->execute([$accountId, (float)$value, $unit, $date]);
        consumption_response(201, ['ok'=>true, 'message'=>'Consumption record created successfully.']);
    }
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) consumption_response(422, ['ok'=>false, 'message'=>'A valid record ID is required.']);
    $stmt = $pdo->prepare('UPDATE consumption_records SET utility_account_id = ?, consumption_value = ?, unit = ?, recorded_date = ? WHERE id = ?');
    $stmt->execute([$accountId, (float)$value, $unit, $date, $id]);
    if (!$stmt->rowCount()) {
        $exists = $pdo->prepare('SELECT id FROM consumption_records WHERE id = ?'); $exists->execute([$id]);
        if (!$exists->fetchColumn()) consumption_response(404, ['ok'=>false, 'message'=>'Consumption record not found.']);
    }
    consumption_response(200, ['ok'=>true, 'message'=>'Consumption record updated successfully.']);
} catch (Throwable $e) {
    error_log('Meterly consumption management error: ' . $e->getMessage());
    consumption_response(500, ['ok'=>false, 'message'=>'Could not save consumption record. Check the PHP error log and confirm the consumption_records columns.']);
}
