<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function api_response(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    api_response(405, ['ok' => false, 'message' => 'Method not allowed.']);
}
if (empty($_SESSION['user_id'])) {
    api_response(401, ['ok' => false, 'message' => 'Please sign in first.']);
}

$check = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
$check->execute([(int)$_SESSION['user_id']]);
$role = $check->fetchColumn();
if ($role !== 'admin') {
    api_response(403, ['ok' => false, 'message' => 'Administrator access is required.']);
}

try {
    $data = [];
    $data['users'] = $pdo->query(
        'SELECT id, full_name, email, role, created_at FROM users ORDER BY created_at DESC'
    )->fetchAll();

    $data['utility_accounts'] = $pdo->query(
        'SELECT ua.id, ua.user_id, u.full_name AS customer_name, u.email, ua.provider_name, ua.account_number, ua.utility_type, ua.created_at
         FROM utility_accounts ua INNER JOIN users u ON u.id = ua.user_id
         ORDER BY ua.created_at DESC'
    )->fetchAll();

    $data['bills'] = $pdo->query(
        'SELECT b.id, b.utility_account_id, u.full_name AS customer_name, ua.provider_name, ua.account_number, b.bill_title, b.amount, b.billing_period, b.due_date, b.status, b.created_at
         FROM bills b INNER JOIN utility_accounts ua ON ua.id = b.utility_account_id
         INNER JOIN users u ON u.id = ua.user_id
         ORDER BY b.due_date ASC'
    )->fetchAll();

    $data['payments'] = $pdo->query(
        'SELECT p.id, p.bill_id, p.transaction_reference, u.full_name AS customer_name, b.bill_title, p.amount, p.payment_method, p.payment_status, p.payment_date, p.created_at
         FROM payments p INNER JOIN bills b ON b.id = p.bill_id
         INNER JOIN utility_accounts ua ON ua.id = b.utility_account_id
         INNER JOIN users u ON u.id = ua.user_id
         ORDER BY p.created_at DESC'
    )->fetchAll();

    $data['consumption_records'] = $pdo->query(
        'SELECT cr.id, cr.utility_account_id, u.full_name AS customer_name, ua.provider_name, ua.account_number, cr.consumption_value, cr.unit, cr.recorded_date, cr.created_at
         FROM consumption_records cr INNER JOIN utility_accounts ua ON ua.id = cr.utility_account_id
         INNER JOIN users u ON u.id = ua.user_id
         ORDER BY cr.recorded_date DESC'
    )->fetchAll();

    $data['reminders'] = $pdo->query(
        'SELECT r.id, u.full_name AS customer_name, b.bill_title, r.reminder_date, r.message, r.status, r.created_at
         FROM reminders r INNER JOIN bills b ON b.id = r.bill_id
         INNER JOIN utility_accounts ua ON ua.id = b.utility_account_id
         INNER JOIN users u ON u.id = ua.user_id
         ORDER BY r.reminder_date ASC'
    )->fetchAll();

    api_response(200, ['ok' => true, 'data' => $data]);
} catch (Throwable $e) {
    error_log('Meterly admin data error: ' . $e->getMessage());
    api_response(500, ['ok' => false, 'message' => 'Could not read all database tables. Check the PHP error log and confirm the table columns match the database screenshots.']);
}
