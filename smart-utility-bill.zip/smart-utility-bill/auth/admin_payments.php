<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function payment_response(int $status, array $body): never { http_response_code($status); echo json_encode($body, JSON_UNESCAPED_UNICODE); exit; }
function ensure_payment_audit_table(PDO $pdo): void {
  $pdo->exec("CREATE TABLE IF NOT EXISTS admin_activity_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NULL,
    action VARCHAR(120) NOT NULL,
    details TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_activity_created_at (created_at),
    INDEX idx_activity_user_id (user_id),
    CONSTRAINT fk_admin_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}
function write_payment_audit(PDO $pdo, int $userId, string $action, string $details): void {
  $stmt = $pdo->prepare('INSERT INTO admin_activity_log (user_id, action, details) VALUES (?, ?, ?)');
  $stmt->execute([$userId, $action, $details]);
}
function refresh_bill_status(PDO $pdo, int $billId): void {
  $bill = $pdo->prepare('SELECT amount, due_date FROM bills WHERE id = ? LIMIT 1');
  $bill->execute([$billId]);
  $billRow = $bill->fetch(PDO::FETCH_ASSOC);
  if (!$billRow) return;
  $paid = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE bill_id = ? AND payment_status = 'successful'");
  $paid->execute([$billId]);
  $successfulTotal = (int) round((float)$paid->fetchColumn() * 100);
  $billTotal = (int) round((float)$billRow['amount'] * 100);
  $status = ($billTotal > 0 && $successfulTotal >= $billTotal) ? 'paid' : (((string)$billRow['due_date'] < date('Y-m-d')) ? 'overdue' : 'unpaid');
  $update = $pdo->prepare('UPDATE bills SET status = ? WHERE id = ?');
  $update->execute([$status, $billId]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') payment_response(405, ['ok'=>false,'message'=>'Method not allowed.']);
if (empty($_SESSION['user_id'])) payment_response(401, ['ok'=>false,'message'=>'Please sign in first.']);
$adminId = (int)$_SESSION['user_id'];
$role = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
$role->execute([$adminId]);
if ($role->fetchColumn() !== 'admin') payment_response(403, ['ok'=>false,'message'=>'Administrator access is required.']);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) payment_response(400, ['ok'=>false,'message'=>'Invalid request data.']);
$action = (string)($input['action'] ?? '');
try {
  ensure_payment_audit_table($pdo);
  $pdo->beginTransaction();
  if ($action === 'delete') {
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) { $pdo->rollBack(); payment_response(422,['ok'=>false,'message'=>'A valid payment ID is required.']); }
    $find = $pdo->prepare('SELECT p.bill_id, p.transaction_reference, p.amount, p.payment_status, b.bill_title FROM payments p LEFT JOIN bills b ON b.id=p.bill_id WHERE p.id=? FOR UPDATE');
    $find->execute([$id]); $old = $find->fetch(PDO::FETCH_ASSOC);
    if (!$old) { $pdo->rollBack(); payment_response(404,['ok'=>false,'message'=>'Payment record not found.']); }
    $del = $pdo->prepare('DELETE FROM payments WHERE id=?'); $del->execute([$id]);
    refresh_bill_status($pdo, (int)$old['bill_id']);
    $details = sprintf('Payment #%d · %s · %s · ₦%s · %s', $id, $old['transaction_reference'], $old['bill_title'] ?? ('Bill #'.$old['bill_id']), number_format((float)$old['amount'],2), $old['payment_status']);
    write_payment_audit($pdo, $adminId, 'Payment deleted', $details);
    $pdo->commit();
    payment_response(200,['ok'=>true,'message'=>'Payment record deleted, bill status refreshed, and activity recorded.']);
  }
  if (!in_array($action,['create','update'],true)) { $pdo->rollBack(); payment_response(400,['ok'=>false,'message'=>'Unknown action.']); }
  $billId = filter_var($input['bill_id'] ?? null,FILTER_VALIDATE_INT);
  $amount = $input['amount'] ?? null;
  $method = trim((string)($input['payment_method'] ?? ''));
  $status = (string)($input['payment_status'] ?? 'pending');
  $amountValid = is_numeric($amount) && is_finite((float)$amount)
    && (float)$amount > 0 && (float)$amount <= 999999999.99
    && preg_match('/^\d{1,9}(\.\d{1,2})?$/', (string)$amount);
  if (!$billId || $billId < 1 || !$amountValid ||
      !in_array($method,['Bank transfer','Card','Cash','Other'],true) ||
      !in_array($status,['pending','successful','failed'],true)) {
    $pdo->rollBack(); payment_response(422,['ok'=>false,'message'=>'Enter a valid bill, positive amount, payment method and status.']);
  }
  $billCheck=$pdo->prepare('SELECT id, bill_title FROM bills WHERE id=? FOR UPDATE'); $billCheck->execute([$billId]); $bill=$billCheck->fetch(PDO::FETCH_ASSOC);
  if (!$bill) { $pdo->rollBack(); payment_response(404,['ok'=>false,'message'=>'Selected bill was not found.']); }
  if ($action === 'create') {
    $reference = 'MTY-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4)));
    $date = $status === 'successful' ? date('Y-m-d H:i:s') : null;
    $stmt=$pdo->prepare('INSERT INTO payments (bill_id,transaction_reference,amount,payment_method,payment_status,payment_date) VALUES (?,?,?,?,?,?)');
    $stmt->execute([$billId,$reference,(float)$amount,$method,$status,$date]);
    $paymentId = (int)$pdo->lastInsertId();
    $auditAction = 'Payment recorded';
    $details = sprintf('Payment #%d · %s · %s · ₦%s · %s · %s', $paymentId, $reference, $bill['bill_title'], number_format((float)$amount,2), $method, $status);
  } else {
    $id=filter_var($input['id'] ?? null,FILTER_VALIDATE_INT);
    if (!$id || $id < 1) { $pdo->rollBack(); payment_response(422,['ok'=>false,'message'=>'A valid payment ID is required.']); }
    $oldStmt=$pdo->prepare('SELECT p.bill_id,p.transaction_reference,p.amount,p.payment_method,p.payment_status,b.bill_title FROM payments p LEFT JOIN bills b ON b.id=p.bill_id WHERE p.id=? FOR UPDATE');
    $oldStmt->execute([$id]); $old=$oldStmt->fetch(PDO::FETCH_ASSOC);
    if (!$old) { $pdo->rollBack(); payment_response(404,['ok'=>false,'message'=>'Payment record not found.']); }
    $date = $status === 'successful' ? date('Y-m-d H:i:s') : null;
    $stmt=$pdo->prepare('UPDATE payments SET bill_id=?,amount=?,payment_method=?,payment_status=?,payment_date=? WHERE id=?');
    $stmt->execute([$billId,(float)$amount,$method,$status,$date,$id]);
    refresh_bill_status($pdo,(int)$old['bill_id']);
    $auditAction = ($old['payment_status'] !== $status) ? 'Payment status changed' : 'Payment updated';
    $details = sprintf('Payment #%d · %s · %s · ₦%s · %s · %s (previous: %s · ₦%s · %s)', $id, $old['transaction_reference'], $bill['bill_title'], number_format((float)$amount,2), $method, $status, $old['payment_status'], number_format((float)$old['amount'],2), $old['bill_title'] ?? ('Bill #'.$old['bill_id']));
  }
  refresh_bill_status($pdo,(int)$billId);
  write_payment_audit($pdo, $adminId, $auditAction, $details);
  $pdo->commit();
  payment_response(200,['ok'=>true,'message'=> $action === 'create' ? 'Payment record created, bill status refreshed, and activity recorded.' : 'Payment record updated, bill status refreshed, and activity recorded.']);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  error_log('Meterly payment management error: '.$e->getMessage());
  payment_response(500,['ok'=>false,'message'=>'Could not save this payment. Check the PHP error log and database table structure.']);
}
