<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
function reminder_response(int $status,array $body): never { http_response_code($status); echo json_encode($body,JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') reminder_response(405,['ok'=>false,'message'=>'Method not allowed.']);
if (empty($_SESSION['user_id'])) reminder_response(401,['ok'=>false,'message'=>'Please sign in first.']);
$auth=$pdo->prepare('SELECT role FROM users WHERE id=? LIMIT 1');$auth->execute([(int)$_SESSION['user_id']]);if($auth->fetchColumn()!=='admin')reminder_response(403,['ok'=>false,'message'=>'Administrator access is required.']);
$input=json_decode(file_get_contents('php://input'),true);if(!is_array($input))reminder_response(400,['ok'=>false,'message'=>'Invalid request data.']);$action=$input['action']??'';
try {
 if($action==='delete'){$id=filter_var($input['id']??null,FILTER_VALIDATE_INT);if(!$id||$id<1)reminder_response(422,['ok'=>false,'message'=>'A valid reminder ID is required.']);$q=$pdo->prepare('DELETE FROM reminders WHERE id=?');$q->execute([$id]);if(!$q->rowCount())reminder_response(404,['ok'=>false,'message'=>'Reminder not found.']);reminder_response(200,['ok'=>true,'message'=>'Reminder deleted.']);}
 if(!in_array($action,['create','update'],true))reminder_response(400,['ok'=>false,'message'=>'Unknown reminder action.']);
 $bill=filter_var($input['bill_id']??null,FILTER_VALIDATE_INT);
 $dateRaw=$input['reminder_date']??'';$messageRaw=$input['message']??'';$status=$input['status']??'';
 $date=is_string($dateRaw)?trim($dateRaw):'';
 $message=is_string($messageRaw)?trim($messageRaw):'';
 $parsedDate=DateTime::createFromFormat('!Y-m-d',$date);
 if(!$bill||$bill<1||!$parsedDate||$parsedDate->format('Y-m-d')!==$date||
    $message===''||mb_strlen($message)>255||
    !is_string($status)||!in_array($status,['pending','sent','cancelled'],true))
   reminder_response(422,['ok'=>false,'message'=>'Choose a bill, a real calendar date, a message (up to 255 characters), and a valid status.']);
 $check=$pdo->prepare('SELECT id FROM bills WHERE id=?');$check->execute([$bill]);if(!$check->fetchColumn())reminder_response(422,['ok'=>false,'message'=>'The selected bill was not found.']);
 if($action==='create'){$q=$pdo->prepare('INSERT INTO reminders (bill_id,reminder_date,message,status) VALUES (?,?,?,?)');$q->execute([$bill,$date,$message,$status]);reminder_response(201,['ok'=>true,'message'=>'Reminder created successfully.']);}
 $id=filter_var($input['id']??null,FILTER_VALIDATE_INT);if(!$id||$id<1)reminder_response(422,['ok'=>false,'message'=>'A valid reminder ID is required.']);$q=$pdo->prepare('UPDATE reminders SET bill_id=?,reminder_date=?,message=?,status=? WHERE id=?');$q->execute([$bill,$date,$message,$status,$id]);if(!$q->rowCount()){$check=$pdo->prepare('SELECT id FROM reminders WHERE id=?');$check->execute([$id]);if(!$check->fetchColumn())reminder_response(404,['ok'=>false,'message'=>'Reminder not found.']);}reminder_response(200,['ok'=>true,'message'=>'Reminder updated successfully.']);
} catch(Throwable $e){error_log('Meterly reminder management error: '.$e->getMessage());reminder_response(500,['ok'=>false,'message'=>'Could not save reminder. Check the PHP error log.']);}
