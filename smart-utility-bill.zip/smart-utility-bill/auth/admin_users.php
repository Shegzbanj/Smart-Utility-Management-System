<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body);
    exit;
}

if (empty($_SESSION['user_id'])) {
    respond(401, ['ok' => false, 'message' => 'Please sign in first.']);
}

// Verify the role against MySQL on every request.
$stmt = $pdo->prepare('SELECT id, role FROM users WHERE id = ? LIMIT 1');
$stmt->execute([(int) $_SESSION['user_id']]);
$currentUser = $stmt->fetch();

if (!$currentUser) {
    $_SESSION = [];
    session_destroy();
    respond(401, ['ok' => false, 'message' => 'Your account could not be verified. Please sign in again.']);
}

$_SESSION['user_role'] = $currentUser['role'];

if ($currentUser['role'] !== 'admin') {
    respond(403, ['ok' => false, 'message' => 'Administrator access is required.']);
}

$users = $pdo->query(
    'SELECT id, full_name, email, role, created_at FROM users ORDER BY created_at DESC'
)->fetchAll();

respond(200, ['ok' => true, 'users' => $users]);
