<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Please sign in first.']);
    exit;
}
if (empty($_SESSION['meterly_csrf_token'])) {
    $_SESSION['meterly_csrf_token'] = bin2hex(random_bytes(32));
}
echo json_encode(['ok' => true, 'csrf_token' => $_SESSION['meterly_csrf_token']]);
