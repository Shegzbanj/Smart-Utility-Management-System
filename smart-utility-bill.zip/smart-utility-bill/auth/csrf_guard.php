<?php
declare(strict_types=1);

/**
 * Meterly CSRF protection for authenticated state-changing JSON requests.
 * The frontend sends the token in the X-CSRF-Token request header.
 */
function meterly_require_csrf(): void
{
    if (!in_array(($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        return;
    }

    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => false, 'message' => 'Please sign in first.']);
        exit;
    }

    $expected = $_SESSION['meterly_csrf_token'] ?? '';
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

    if (!is_string($expected) || $expected === '' ||
        !is_string($provided) || $provided === '' ||
        !hash_equals($expected, $provided)) {
        http_response_code(419);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => false, 'message' => 'Security token expired or invalid. Refresh the page and try again.']);
        exit;
    }
}
