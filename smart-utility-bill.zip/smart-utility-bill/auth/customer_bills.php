<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function customer_bill_response(int $status, array $body): never { http_response_code($status); echo json_encode($body, JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'GET') customer_bill_response(405, ['ok'=>false,'message'=>'Method not allowed.']);
if (empty($_SESSION['user_id'])) customer_bill_response(401, ['ok'=>false,'message'=>'Please sign in first.']);
try {
  $userId = (int)$_SESSION['user_id'];
  $roleCheck = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
  $roleCheck->execute([$userId]);
  if ($roleCheck->fetchColumn() !== 'user') customer_bill_response(403, ['ok'=>false,'message'=>'Customer access is required.']);
  $stmt = $pdo->prepare(
    "SELECT b.id, b.utility_account_id, b.bill_title, b.amount, b.billing_period, b.due_date,
       CASE
         WHEN COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.bill_id = b.id AND p.payment_status = 'successful'), 0) >= b.amount THEN 'paid'
         WHEN b.due_date < CURDATE() THEN 'overdue'
         ELSE 'unpaid'
       END AS status,
       b.created_at,
       (SELECT p.payment_status FROM payments p WHERE p.bill_id = b.id ORDER BY p.created_at DESC, p.id DESC LIMIT 1) AS payment_status,
       (SELECT p.transaction_reference FROM payments p WHERE p.bill_id = b.id ORDER BY p.created_at DESC, p.id DESC LIMIT 1) AS transaction_reference,
       (SELECT p.payment_date FROM payments p WHERE p.bill_id = b.id ORDER BY p.created_at DESC, p.id DESC LIMIT 1) AS payment_date,
       COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.bill_id = b.id AND p.payment_status = 'successful'), 0) AS successful_payment_total
     FROM bills b INNER JOIN utility_accounts ua ON ua.id = b.utility_account_id
     WHERE ua.user_id = ? ORDER BY b.created_at DESC, b.id DESC"
  );
  $stmt->execute([$userId]);
  customer_bill_response(200, ['ok'=>true,'bills'=>$stmt->fetchAll()]);
} catch (Throwable $e) {
  error_log('Meterly customer bills error: '.$e->getMessage());
  customer_bill_response(500, ['ok'=>false,'message'=>'Could not load your bills and payment details.']);
}
