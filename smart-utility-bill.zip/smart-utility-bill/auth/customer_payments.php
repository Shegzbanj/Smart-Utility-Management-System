<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function customer_payment_response(int $status, array $body): never {
  http_response_code($status);
  echo json_encode($body, JSON_UNESCAPED_UNICODE);
  exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
  customer_payment_response(405, ['ok' => false, 'message' => 'Method not allowed.']);
}
if (empty($_SESSION['user_id'])) {
  customer_payment_response(401, ['ok' => false, 'message' => 'Please sign in first.']);
}
try {
  $userId = (int) $_SESSION['user_id'];
  $role = $pdo->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
  $role->execute([$userId]);
  if ($role->fetchColumn() !== 'user') {
    customer_payment_response(403, ['ok' => false, 'message' => 'Customer access is required.']);
  }
  $stmt = $pdo->prepare(
    "SELECT p.id, p.transaction_reference, p.amount, p.payment_method, p.payment_status,
            COALESCE(p.payment_date, p.created_at) AS receipt_date,
            b.bill_title, ua.provider_name, ua.account_number, ua.utility_type,
            u.full_name, u.email
       FROM payments p
       INNER JOIN bills b ON b.id = p.bill_id
       INNER JOIN utility_accounts ua ON ua.id = b.utility_account_id
       INNER JOIN users u ON u.id = ua.user_id
      WHERE ua.user_id = ? AND p.payment_status = 'successful'
      ORDER BY COALESCE(p.payment_date, p.created_at) DESC, p.id DESC"
  );
  $stmt->execute([$userId]);
  $payments = [];
  foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $payments[] = [
      'id' => (int) $row['id'],
      'reference' => (string) $row['transaction_reference'],
      'amount' => (float) $row['amount'],
      'method' => (string) ($row['payment_method'] ?? 'Not recorded'),
      'status' => strtoupper((string) $row['payment_status']),
      'createdAt' => (string) $row['receipt_date'],
      'billTitle' => (string) $row['bill_title'],
      'type' => ucfirst((string) $row['utility_type']),
      'provider' => (string) $row['provider_name'],
      'accountNumber' => (string) $row['account_number'],
      'customer' => (string) $row['full_name'] . ' (' . (string) $row['email'] . ')',
      'isDatabasePayment' => true
    ];
  }
  customer_payment_response(200, ['ok' => true, 'payments' => $payments]);
} catch (Throwable $e) {
  error_log('Meterly customer payments error: ' . $e->getMessage());
  customer_payment_response(500, ['ok' => false, 'message' => 'Could not load your payment receipts.']);
}
