<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/csrf_guard.php';
meterly_require_csrf();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function customer_reply(int $status, array $data): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = filter_var($_SESSION['user_id'] ?? null, FILTER_VALIDATE_INT);
if (!$userId) customer_reply(401, ['ok' => false, 'message' => 'Please sign in again.']);

$verify = $pdo->prepare('SELECT id, role FROM users WHERE id = ? LIMIT 1');
$verify->execute([$userId]);
$user = $verify->fetch();
if (!$user) customer_reply(401, ['ok' => false, 'message' => 'Your login session could not be verified. Please sign out and sign in again.']);

$_SESSION['user_role'] = $user['role'];
if ($user['role'] !== 'user') {
    customer_reply(403, ['ok' => false, 'message' => 'This feature is for customer accounts. Please sign out and sign in with a customer account.']);
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $pdo->prepare(
            'SELECT id, provider_name, account_number, utility_type, created_at
             FROM utility_accounts WHERE user_id = ? ORDER BY created_at DESC'
        );
        $stmt->execute([$userId]);
        customer_reply(200, ['ok' => true, 'accounts' => $stmt->fetchAll()]);
    }

    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) customer_reply(400, ['ok' => false, 'message' => 'Invalid request data.']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $provider = trim((string)($input['provider_name'] ?? ''));
        $accountNumber = trim((string)($input['account_number'] ?? ''));
        $type = (string)($input['utility_type'] ?? '');
        if ($provider === '' || mb_strlen($provider) > 150 || $accountNumber === '' || mb_strlen($accountNumber) > 100 || !in_array($type, ['electricity', 'water', 'internet', 'other'], true)) {
            customer_reply(422, ['ok' => false, 'message' => 'Enter a valid provider and account number.']);
        }
        $stmt = $pdo->prepare('INSERT INTO utility_accounts (user_id, provider_name, account_number, utility_type) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $provider, $accountNumber, $type]);
        customer_reply(201, ['ok' => true, 'message' => 'Utility account saved successfully.', 'id' => (int)$pdo->lastInsertId()]);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) customer_reply(422, ['ok' => false, 'message' => 'A valid utility account is required.']);
        $stmt = $pdo->prepare('DELETE FROM utility_accounts WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);
        if ($stmt->rowCount() === 0) customer_reply(404, ['ok' => false, 'message' => 'Utility account not found.']);
        customer_reply(200, ['ok' => true, 'message' => 'Utility account removed.']);
    }

    customer_reply(405, ['ok' => false, 'message' => 'Method not allowed.']);
} catch (PDOException $e) {
    error_log('Meterly customer utility account error: ' . $e->getMessage());
    if ($e->getCode() === '23000') customer_reply(409, ['ok' => false, 'message' => 'This utility account conflicts with an existing record or is linked to other records.']);
    customer_reply(500, ['ok' => false, 'message' => 'A database error occurred. Check the PHP error log.']);
} catch (Throwable $e) {
    error_log('Meterly customer utility account error: ' . $e->getMessage());
    customer_reply(500, ['ok' => false, 'message' => 'An unexpected error occurred.']);
}
