<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(405, ['ok' => false, 'message' => 'Method not allowed.']);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond(400, ['ok' => false, 'message' => 'Invalid request.']);
}

$email = strtolower(trim((string)($input['email'] ?? '')));
$password = (string)($input['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '' || strlen($email) > 150) {
    respond(422, ['ok' => false, 'message' => 'Enter your email address and password.']);
}

// Store only a one-way hash of the email/IP pair in the throttle table.
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
$attemptKey = hash('sha256', $email . '|' . $ip);

try {
    $checkLimit = $pdo->prepare(
        'SELECT attempts, first_attempt_at, locked_until
         FROM login_attempts
         WHERE attempt_key = ?
         LIMIT 1'
    );
    $checkLimit->execute([$attemptKey]);
    $limit = $checkLimit->fetch();

    if ($limit && !empty($limit['locked_until'])) {
        $lockedUntil = strtotime((string)$limit['locked_until']);
        if ($lockedUntil !== false && $lockedUntil > time()) {
            $retryAfter = max(1, $lockedUntil - time());
            header('Retry-After: ' . $retryAfter);
            respond(429, ['ok' => false, 'message' => 'Too many unsuccessful sign-in attempts. Please wait 15 minutes before trying again.']);
        }
    }

    $stmt = $pdo->prepare(
        'SELECT id, full_name, email, password, role
         FROM users
         WHERE email = ?
         LIMIT 1'
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        // Ensure the throttle row exists, then update it safely under a row lock.
        $pdo->prepare(
            'INSERT IGNORE INTO login_attempts
             (attempt_key, attempts, first_attempt_at, last_attempt_at, locked_until)
             VALUES (?, 0, NOW(), NOW(), NULL)'
        )->execute([$attemptKey]);

        $pdo->beginTransaction();
        $rowStmt = $pdo->prepare(
            'SELECT attempts, first_attempt_at
             FROM login_attempts
             WHERE attempt_key = ?
             FOR UPDATE'
        );
        $rowStmt->execute([$attemptKey]);
        $row = $rowStmt->fetch();

        $firstTime = strtotime((string)($row['first_attempt_at'] ?? '')) ?: 0;
        $count = ($firstTime < time() - 900) ? 1 : ((int)($row['attempts'] ?? 0) + 1);
        $firstAt = ($count === 1) ? 'NOW()' : 'first_attempt_at';
        $locked = ($count >= 5) ? date('Y-m-d H:i:s', time() + 900) : null;

        $update = $pdo->prepare(
            'UPDATE login_attempts
             SET attempts = ?, first_attempt_at = ' . $firstAt . ',
                 last_attempt_at = NOW(), locked_until = ?
             WHERE attempt_key = ?'
        );
        $update->execute([$count, $locked, $attemptKey]);
        $pdo->commit();

        if ($count >= 5) {
            header('Retry-After: 900');
            respond(429, ['ok' => false, 'message' => 'Too many unsuccessful sign-in attempts. Please wait 15 minutes before trying again.']);
        }

        respond(401, ['ok' => false, 'message' => 'Email or password is incorrect.']);
    }

    // A successful login clears the failed-attempt counter for this email/IP pair.
    $pdo->prepare('DELETE FROM login_attempts WHERE attempt_key = ?')->execute([$attemptKey]);

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];

    respond(200, [
        'ok' => true,
        'message' => 'Signed in successfully.',
        'user' => [
            'id' => (int)$user['id'],
            'name' => $user['full_name'],
            'email' => $user['email'],
            'role' => $user['role']
        ]
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Meterly login error: ' . $e->getMessage());
    respond(500, ['ok' => false, 'message' => 'Sign-in is temporarily unavailable. Please try again.']);
}
