<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['ok'=>false,'message'=>'Not signed in.']); exit; }
echo json_encode(['ok'=>true,'user'=>['id'=>(int)$_SESSION['user_id'],'name'=>$_SESSION['user_name'] ?? '', 'email'=>$_SESSION['user_email'] ?? '', 'role'=>$_SESSION['user_role'] ?? 'user']]);
