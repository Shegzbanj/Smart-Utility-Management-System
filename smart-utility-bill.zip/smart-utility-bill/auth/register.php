<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function respond(int $status, array $body): never { http_response_code($status); echo json_encode($body); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(405, ['ok'=>false,'message'=>'Method not allowed.']);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) respond(400, ['ok'=>false,'message'=>'Invalid request.']);
$name = trim((string)($input['name'] ?? ''));
$email = strtolower(trim((string)($input['email'] ?? '')));
$password = (string)($input['password'] ?? '');
if ($name === '' || mb_strlen($name) > 120) respond(422, ['ok'=>false,'message'=>'Enter your name (up to 120 characters).']);
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) respond(422, ['ok'=>false,'message'=>'Enter a valid email address.']);
if (strlen($password) < 12 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^A-Za-z0-9]/', $password)) respond(422, ['ok'=>false,'message'=>'Use at least 12 characters with uppercase, lowercase, a number and a symbol.']);
try {
  $check = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1'); $check->execute([$email]);
  if ($check->fetch()) respond(409, ['ok'=>false,'message'=>'An account with this email already exists. Please sign in.']);
  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $pdo->prepare("INSERT INTO users (full_name,email,password,role) VALUES (?,?,?,'user')");
  $stmt->execute([$name,$email,$hash]);
  session_regenerate_id(true);
  $_SESSION['user_id'] = (int)$pdo->lastInsertId();
  $_SESSION['user_name'] = $name;
  $_SESSION['user_email'] = $email;
  $_SESSION['user_role'] = 'user';
  respond(201, ['ok'=>true,'message'=>'Account created successfully.','user'=>['id'=>$_SESSION['user_id'],'name'=>$name,'email'=>$email,'role'=>'user']]);
} catch (PDOException $e) { error_log($e->getMessage()); respond(500,['ok'=>false,'message'=>'Could not create your account. Please try again.']); }
